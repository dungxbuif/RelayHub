#!/bin/sh
set -eu
npm ci --no-audit --no-fund
npm run build
npm pack --ignore-scripts
